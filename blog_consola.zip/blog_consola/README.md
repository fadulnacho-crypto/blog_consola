# Blog en consola

Sistema de blog que funciona en la terminal, hecho en Python. Permite ver, buscar, filtrar y validar publicaciones guardadas en memoria.

## Cómo ejecutarlo

Requiere Python 3. Desde la carpeta raíz del proyecto (donde está `main.py`):

```
python main.py
```

## Funcionalidades del menú

1. **Ver todos los posts**: muestra título, autor, estado y tags de cada publicación.
2. **Buscar por título**: encuentra posts que contengan una palabra en el título (sin importar mayúsculas).
3. **Filtrar por tag**: muestra los posts que tienen una etiqueta (sin importar mayúsculas).
4. **Validar posts**: revisa que cada post tenga todas sus claves, campos no vacíos, autor como diccionario y un estado válido.
5. **Salir**: cierra el programa.

Si se ingresa texto o un número fuera de rango en el menú, el programa avisa y vuelve a mostrarlo.

## Estructura del proyecto

```
blog_consola/
├── main.py              # Punto de entrada: coordina el menú y las opciones
├── README.md
└── blog/
    ├── __init__.py      # Indica que blog/ es un paquete
    ├── datos.py         # Autor, estados, etiquetas y lista de posts
    ├── menu.py          # Menú, input() y presentación en consola
    ├── operaciones.py   # Búsqueda por título y filtrado por tag
    └── validaciones.py  # Reglas para validar posts y entradas
```

Uno de los posts está incompleto a propósito, para comprobar que la validación detecta errores.

## Autor

Ignacio García Fadul
