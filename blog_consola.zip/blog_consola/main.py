# main.py
# Punto de entrada del sistema: coordina los módulos del paquete blog

from blog.datos import posts, etiquetas_blog
from blog.operaciones import buscar_por_titulo, filtrar_por_tag
from blog.menu import mostrar_menu, pedir_texto, listar_posts, mostrar_validacion


def procesar_opcion(opcion, lista):
    """Ejecuta la acción según la opción. Retorna False si hay que salir."""
    if opcion == 1:
        print("\n--- Todos los posts ---")
        listar_posts(lista)

    elif opcion == 2:
        termino = pedir_texto("Buscar por título: ")
        if termino:
            resultados = buscar_por_titulo(lista, termino)
            print("\n--- Resultados de la búsqueda ---")
            if resultados:
                listar_posts(resultados)
            else:
                print(f"No se encontraron posts con '{termino}' en el título.")

    elif opcion == 3:
        tag = pedir_texto("Ingresá un tag: ")
        if tag:
            resultados = filtrar_por_tag(lista, tag)
            print(f"\n--- Posts con el tag '{tag.lower()}' ---")
            if resultados:
                listar_posts(resultados)
            else:
                print("No hay posts con ese tag.")
                print("Tags disponibles:", ", ".join(sorted(etiquetas_blog)))

    elif opcion == 4:
        print("\n--- Validación de posts ---")
        mostrar_validacion(lista)

    elif opcion == 5:
        print("¡Gracias por usar el blog! Hasta luego.")
        return False

    else:
        print("Opción inválida. Ingresá un número del 1 al 5.")

    return True


if __name__ == "__main__":
    continuar = True
    while continuar:
        opcion = mostrar_menu()
        if opcion is None:
            continue  # entrada no numérica: vuelve a mostrar el menú
        continuar = procesar_opcion(opcion, posts)
