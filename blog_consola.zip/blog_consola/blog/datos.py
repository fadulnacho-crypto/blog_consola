# blog/datos.py
# Estructuras de datos base del blog (se guardan en memoria)

# Perfil del autor (diccionario)
perfil_autor = {
    "nombre": "Ignacio García Fadul",
    "email": "fadulnacho@gmail.com",
    "bio": "Estudiante de Comercio Internacional apasionado por la tecnología y el análisis de datos.",
    "redes_sociales": ["Instagram", "LinkedIn", "Twitter"]
}

# Estados posibles de un post (tupla - inmutable)
estados_post = ("borrador", "publicado", "archivado")

# Etiquetas del blog (set - no permite duplicados)
etiquetas_blog = {"python", "programacion", "tecnologia", "datos"}

# Claves que todo post debe tener
CLAVES_REQUERIDAS = ("titulo", "contenido", "estado", "etiquetas", "autor")

# Catálogo de contenido (lista de diccionarios)
# El autor se guarda como diccionario anidado, no como texto
posts = [
    {
        "titulo": "Introducción a Python",
        "contenido": "En este post vamos a ver los conceptos básicos de Python.",
        "estado": estados_post[1],  # "publicado"
        "etiquetas": ["python", "programacion"],
        "autor": perfil_autor
    },
    {
        "titulo": "Cómo modelar datos sin una base de datos",
        "contenido": "Usar listas, diccionarios, tuplas y sets para organizar información en memoria.",
        "estado": estados_post[0],  # "borrador"
        "etiquetas": ["datos", "python"],
        "autor": perfil_autor
    },
    {
        "titulo": "Buenas prácticas en el manejo de datos",
        "contenido": "Algunos tips para evitar errores comunes al trabajar con estructuras de datos.",
        "estado": estados_post[2],  # "archivado"
        "etiquetas": ["tecnologia", "datos"],
        "autor": perfil_autor
    },
    # Post incompleto A PROPÓSITO para probar las validaciones:
    # contenido vacío, sin "etiquetas" y autor como texto en vez de diccionario
    {
        "titulo": "Post sin terminar",
        "contenido": "",
        "estado": "pendiente",
        "autor": "Ignacio"
    }
]
