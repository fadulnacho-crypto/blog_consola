# blog/validaciones.py
# Reglas lógicas para verificar que un post tenga datos correctos

from blog.datos import estados_post, CLAVES_REQUERIDAS


def validar_post(post):
    """Verifica las reglas del post. Retorna (True, []) si es válido,
    o (False, lista_de_errores) si tiene problemas."""
    errores = []

    # Claves existentes y campos no vacíos
    for clave in CLAVES_REQUERIDAS:
        if clave not in post:
            errores.append(f"falta la clave '{clave}'")
        elif not post[clave]:
            errores.append(f"el campo '{clave}' está vacío")

    # El autor debe ser un diccionario con nombre
    if "autor" in post and post["autor"]:
        if not isinstance(post["autor"], dict):
            errores.append("el autor debe ser un diccionario, no un texto")
        elif not post["autor"].get("nombre"):
            errores.append("el autor no tiene nombre")

    # El estado debe ser uno de los permitidos
    if post.get("estado") and post["estado"] not in estados_post:
        errores.append(f"el estado '{post['estado']}' no es válido")

    return len(errores) == 0, errores


def texto_valido(texto):
    """Retorna True si el texto no está vacío (sirve para búsquedas)."""
    return texto.strip() != ""
