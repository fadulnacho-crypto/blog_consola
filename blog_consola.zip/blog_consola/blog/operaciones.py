# blog/operaciones.py
# Funciones de búsqueda y filtrado de posts (no imprimen, solo retornan resultados)


def obtener_nombre_autor(post):
    """Retorna el nombre del autor de forma segura (sin KeyError)."""
    autor = post.get("autor")
    if isinstance(autor, dict):
        return autor.get("nombre", "Sin nombre")
    return "Autor inválido"


def buscar_por_titulo(lista, termino):
    """Retorna los posts cuyo título contiene el término (sin importar mayúsculas)."""
    termino = termino.lower()
    resultados = []
    for post in lista:
        if termino in post.get("titulo", "").lower():
            resultados.append(post)
    return resultados


def filtrar_por_tag(lista, tag):
    """Retorna los posts que tienen el tag indicado (sin importar mayúsculas)."""
    tag = tag.lower()
    resultados = []
    for post in lista:
        for etiqueta in post.get("etiquetas", []):
            if etiqueta.lower() == tag:
                resultados.append(post)
                break
    return resultados
