# blog/menu.py
# Interfaz de consola: muestra el menú, pide datos con input() e imprime resultados

from blog.operaciones import obtener_nombre_autor
from blog.validaciones import validar_post, texto_valido


def mostrar_menu():
    """Muestra el menú y retorna la opción elegida como número entero.
    Si el usuario ingresa algo no numérico, retorna None."""
    print("\n===== MENÚ DEL BLOG =====")
    print("1. Ver todos los posts")
    print("2. Buscar por título")
    print("3. Filtrar por tag")
    print("4. Validar posts")
    print("5. Salir")
    try:
        return int(input("Elegí una opción: ").strip())
    except ValueError:
        print("Error: tenés que ingresar un número, no texto.")
        return None


def pedir_texto(mensaje):
    """Pide un texto al usuario y retorna None si lo deja vacío."""
    texto = input(mensaje).strip()
    if not texto_valido(texto):
        print("Error: la búsqueda no puede estar vacía.")
        return None
    return texto


def mostrar_post(post):
    """Imprime un post en una línea, usando .get() por si faltan datos."""
    titulo = post.get("titulo") or "Sin título"
    etiquetas = ", ".join(post.get("etiquetas", [])) or "sin tags"
    print(f"- {titulo} | Autor: {obtener_nombre_autor(post)} | "
          f"Estado: {post.get('estado', '-')} | Tags: {etiquetas}")


def listar_posts(lista):
    """Recorre la lista de posts y los muestra."""
    if not lista:
        print("No hay posts para mostrar.")
        return
    for post in lista:
        mostrar_post(post)


def mostrar_validacion(lista):
    """Valida cada post de la lista y muestra el resultado."""
    for numero, post in enumerate(lista, start=1):
        es_valido, errores = validar_post(post)
        titulo = post.get("titulo") or "Sin título"
        if es_valido:
            print(f"Post {numero} ({titulo}): válido")
        else:
            print(f"Post {numero} ({titulo}): INVÁLIDO")
            for error in errores:
                print(f"   - {error}")
